# Forum
Social network for clients ;This is a MERN stack application . It is a small social network app that includes authentication, profiles and forum posts.
# Author

ING Nada Mekki

# Version
1.0.0

# License

This project is licensed under the MIT License

>>Local: http://localhost:3000/

# Or run with Node
$ npm run dev